print("Hello world!")
